<?php
class EmotoModel extends Model{

}
?>