<?php
class SiteModel extends Model{

}
?>