<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>

<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>index</title>
	<meta name="generator" content="TextMate http://macromates.com/">
	<meta name="author" content="Kyoma Houohin">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="__PUBLIC__/css/bootstrap.css" type="text/css" title="no title" charset="utf-8">
	<link rel="stylesheet" href="__PUBLIC__/css/bootstrap-responsive.css" type="text/css" title="no title" charset="utf-8">
	<link rel="stylesheet" href="__PUBLIC__/css/style.css" type="text/css" title="no title" charset="utf-8">
</head>
<body>
	<div class="container">
		<div class="page-header">
		    <h1><?php echo $summery['title'];?></h1>
		</div>
		<div class="row">
			<div class="span12"><?php echo $summery['summery'];?></div>
		</div>
		<hr />
		<div class="row summery-footer">
			<div class="span12"><a class="btn btn-block" href="__URL__">Back</a></div>
		</div>
	</div>
	<script type="text/javascript" src="__PUBLIC__/js/jQuery.js"></script>
	<script type="text/javascript" src="__PUBLIC__/js/bootstrap.js"></script>
	<script type="text/javascript" src="__PUBLIC__/js/index.js"></script>
	<script type="text/javascript" charset="utf-8">
		
	</script>
</body>
</html>