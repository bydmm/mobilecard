<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN"
   "http://www.w3.org/TR/html4/strict.dtd">

<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title><?php echo $site['title'];?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="__PUBLIC__/css/bootstrap.css" type="text/css" title="no title" charset="utf-8">
  <link rel="stylesheet" href="__PUBLIC__/css/style.css" type="text/css" title="no title" charset="utf-8">
  <link href="<?php echo $site['icon'];?>" rel="apple-touch-icon-precomposed">
</head>
<body>
  <div class="container-fluid">
    <div class="row-fluid header">
      <div class="content">
      <?php echo $site['header'];?>
      </div>
    </div>
    <?php for($i=0; $i < count($blocks); $i = $i + 2 ): ?>
      <?php $first = $blocks[$i]; ?>
      <?php $next = $blocks[$i+1]; ?>
      <div class="row-fluid" style="margin-bottom:1.5%">
        <div draggable="true" class="block span5 offset1" >
          <a
            id="<?php echo $first->id; ?>" 
            order="<?php echo $first->order; ?>" 
            class="custombtn"
            style="
              border-radius:<?php echo $first->border_radius;?>%;
              background-color:<?php echo $first->background_color;?>;
              font-family:<?php echo $first->font_family;?>;
              color:<?php echo $first->title_color;?>;
            "
            href="<?php echo $first->link; ?>">
            <?php echo $first->title; ?>
          </a>
        </div>
        
        <?php if($next):?>
        <div draggable="true" class="block span5" >
          <a 
            id="<?php echo $next->id; ?>" 
            order="<?php echo $next->order; ?>" 
            class="custombtn" 
            style="
              border-radius:<?php echo $next->border_radius;?>%;
              background-color:<?php echo $next->background_color;?>;
              font-family:<?php echo $next->font_family;?>;
              color:<?php echo $next->title_color;?>;
            "
            href="<?php echo $next->link; ?>">
            <?php echo $next->title; ?>
          </a>
        </div>
        <?php endif;?>
      </div>
    <?php endfor;?>
    <div class="row-fluid footer">
      <div class="span12">
        <?php echo $site['footer'];?>
      </div>
    </div>
    <div class="row-fluid mark">
      <div class="span10 offset1">
        <div id="close"></div>
        <div class="content">
        <?php echo $site['mark'];?>
        </div>
      </div>
    </div>
  </div>
  <script type="text/javascript" src="__PUBLIC__/js/jQuery.js"></script>
  <script type="text/javascript" src="__PUBLIC__/js/bootstrap.js"></script>
  <script type="text/javascript" src="__PUBLIC__/js/index.js"></script>
  <script type="text/javascript" charset="utf-8">
    
  </script>
</body>
</html>